#include "governmentTax.h"
#include<iostream>
using namespace std;

template <class T>
void governtmentTax<T> ::display()
{
	cout << taxPer << endl;
}





